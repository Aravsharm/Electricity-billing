package electricity.billing.system;

import java.sql.*;
//import javax.swing.*;
//import java.awt.*;
public class Conn //extends JFrame
{
    Connection c;
    Statement s;
    Conn()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/ebs","root","");
            s = c.createStatement();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void main(String []ar)
    {
      new Conn();
    }

}
