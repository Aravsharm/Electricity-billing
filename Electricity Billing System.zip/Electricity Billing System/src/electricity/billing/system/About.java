package electricity.billing.system;

import java.awt.*;
import javax.swing.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;



public class About extends JFrame
   {
    About()  {
        setSize(700,500);
        setLocation(400,150);
        
        getContentPane().setBackground(Color.WHITE);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/about.jpg"));
        Image i2 = i1.getImage().getScaledInstance(300,200,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,0,300,200);
        add(image);
        JLabel heading = new JLabel("<html>University<br/>Management System </html>");
        heading.setBounds(70,20,300,130);
        heading.setFont(new Font("Tahoma",Font.BOLD,30));
        add(heading);
        
        JLabel name = new JLabel("Developed By: Sumit Vishwakarma");
        name.setBounds(70,220,600,40);
        name.setFont(new Font("Tahoma",Font.BOLD,30));
        add(name);
        
        JLabel rollno = new JLabel("Roll number:50");
        rollno.setBounds(70,280,600,40);
        rollno.setFont(new Font("Tahoma",Font.PLAIN,30));
        add(rollno);
        
        JLabel Contact = new JLabel("Contact : attitudegyan780@gmail.com");
        Contact.setBounds(70,320,600,40);
        Contact.setFont(new Font("Tahoma",Font.BOLD,20));
        add(Contact);
        
        setLayout(null);
        setVisible(true);
         
}

public static void main(String ar[])
    {
       new About();
    }
}
